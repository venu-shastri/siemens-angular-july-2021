import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import {AtoBCommunicatorService} from './AtoBCommunicatorService'

import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';
import { BComponent } from './b.component';
import { AComponent } from './a.component';
import { ApiService } from './apiService';

@NgModule({
  imports:      [ BrowserModule, FormsModule ],
  declarations: [ AppComponent, HelloComponent,BComponent,AComponent],
  bootstrap:    [ AppComponent ],
  providers:[
    AtoBCommunicatorService,
    {provide:"apiAddress",useValue:"http://siemens.com/api"},
    ApiService
  ]
})
export class AppModule { }
