import {Inject,Injectable} from '@angular/core'
import {AtoBCommunicatorService} from './AtoBCommunicatorService'

@Injectable()
export class ApiService{
  subscriptionRef:any;
  constructor( @Inject("apiAddress") public httpAddress:string,public mediator:AtoBCommunicatorService){

    console.log("Service Activated");
    this.subscriptionRef=this.mediator.subscribeForStreamChange().subscribe(this.onDataPublished.bind(this));

  }

  onDataPublished(data:string){

    
    console.log(`Sending data:${data} to api:${this.httpAddress}`);

  }
  dispose(){
this.subscriptionRef.unsubscribe();
  }


}