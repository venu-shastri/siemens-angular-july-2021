import { Component, InjectorType, OnDestroy, OnInit } from '@angular/core';

import { AtoBCommunicatorService } from './AtoBCommunicatorService';
@Component({
  selector: 'b-comp',
  templateUrl: './b.component.html',
  styles: [
    `
      h1 {
        font-family: Lato;
      }
    `
  ]
})
export class BComponent implements OnInit,OnDestroy {
  inputTextList = new Array<string>();
  subScriptionRef:any;
  constructor(public mediator: AtoBCommunicatorService) {
    //let _this=this;
    // this.mediator.subscribeForStreamChange().subscribe(onReceiveData);
    // function onReceiveData(data:string){
    //   console.log(data);
    //   _this.inputTextList.push(data);
    // }
    // this.mediator.subscribeForStreamChange().subscribe(this.onReceiveData.bind(this));

   
  }

  onReceiveData(data: string) {
    console.log(data);
    this.inputTextList.push(data);
  }
  ngOnInit(){
    this.subScriptionRef=this.mediator.subscribeForStreamChange().subscribe(data => {
      this.inputTextList.push(data);
    });
  }
  ngOnDestroy(){
this.subScriptionRef.unsubscribe();
  }
}
