import { Component, InjectorType } from '@angular/core';
import { ApiService } from './apiService';
import {AtoBCommunicatorService} from './AtoBCommunicatorService'
@Component({
  selector: 'a-comp',
  templateUrl:'./a.component.html',
  styles: [`h1 { font-family: Lato; }`],
  providers:[
    ApiService,
    {provide:"apiAddress",useValue:"http://siemens.com/newApi"}]
})
export class AComponent  {
  inputText:string;
  constructor(public mediator:AtoBCommunicatorService,public apiService:ApiService){
    this.inputText=""
  }
  publish(){
    this.mediator.publish(this.inputText);
    this.apiService.onDataPublished(`Data + ${Math.random()}`);
  }
}
