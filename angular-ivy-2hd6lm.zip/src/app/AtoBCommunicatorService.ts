import {Subject} from 'rxjs';
export class AtoBCommunicatorService{

 private stream=new Subject<string>();
  observableStream=this.stream.asObservable();
constructor(){}

publish(data:string){
  this.stream.next(data);
}
subscribeForStreamChange(){
return this.observableStream;
}

}